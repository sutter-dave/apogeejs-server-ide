//some global definitions for the node environment
global.__globals__ = global;
global.__APOGEE_ENVIRONMENT__ = "NODE"; 